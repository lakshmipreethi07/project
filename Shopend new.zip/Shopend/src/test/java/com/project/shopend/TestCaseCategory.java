package com.project.shopend;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.project.shopping.DAO.CategoryDAO;
import com.project.shopping.Model.Category;

public class TestCaseCategory {

	@Autowired
	CategoryDAO categoryDAO;
	@Autowired
	Category category;
	AnnotationConfigApplicationContext context;
	@Before
	public void init(){
		context =new AnnotationConfigApplicationContext();
		context.scan("com.project.*");
		context.refresh();
		categoryDAO=(CategoryDAO)context.getBean("categoryDAO");
		category=(Category)context.getBean("category");
	}
		
	@Test
	public void categoryAddTestCase(){
		
		category.setId("CAT_03");
		category.setName("MOBILES");
		category.setDescription("MOBILE PHONES AND TABLETS");
		assertEquals("AddTestCase", categoryDAO.save(category),true);
	}
	@Test
	public void categoryUpdateTestCase(){
		category.setId("CAT_04");
		category.setName("SECURITY");
		category.setDescription("SECURITY SOLUTIONS EX,CCTV ");
		assertEquals("UpdateTestCase", categoryDAO.save(category),true);
	}
	@Test
	public void categoryDeleteTestCase()
	{                              
		category.setId("CAT_04");
		boolean flag = categoryDAO.delete(category);
		assertEquals("DeleteTestCase " , flag,true);
	    categoryDAO.delete(category);
	}

		}
	
	
	

