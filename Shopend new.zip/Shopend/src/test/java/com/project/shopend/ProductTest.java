package com.project.shopend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.project.shopping.DAO.ProductDAO;
import com.project.shopping.Model.Product;



public class ProductTest {
public static void main(String[] args){
	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
	context.scan("com.project.*");
	context.refresh();
	ProductDAO productDAO=(ProductDAO) context.getBean("productDAO");
	Product product=(Product) context.getBean("product");
	product.setId("CAT_007");
	product.setName("furniture");
	product.setDescription("this is a category");
	product.setPrice("18000-rs");
	if(productDAO.save(product) == true) 
	{
		System.out.println("product created successfully");
	}
	else
	{
		System.out.println("not able to create the product");
	}
	
	}
	

}