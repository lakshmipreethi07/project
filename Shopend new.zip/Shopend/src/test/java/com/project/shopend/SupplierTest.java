package com.project.shopend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.project.shopping.DAO.SupplierDAO;
import com.project.shopping.Model.Supplier;


public class SupplierTest {
public static void main(String[] args){
	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
	context.scan("com.project.*");
	context.refresh();
	SupplierDAO supplierDAO=(SupplierDAO) context.getBean("supplierDAO");
	Supplier supplier=(Supplier) context.getBean("supplier");
	supplier.setId("CAT_006");
	supplier.setSupplier_address("nandanam");
	supplier.setName("furniture");
	supplier.setDescription("this is a category");
	if(supplierDAO.save(supplier) == true) 
	{
		System.out.println("supplier created successfully");
	}
	else
	{
		System.out.println("not able to create the supplier");
	}
	
	}
	

}