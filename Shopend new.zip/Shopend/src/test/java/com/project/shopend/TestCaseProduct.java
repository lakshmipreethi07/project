package com.project.shopend;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.project.shopping.DAO.ProductDAO;
import com.project.shopping.Model.Product;


public class TestCaseProduct {

	@Autowired
	ProductDAO productDAO;
	@Autowired
	Product product;
	AnnotationConfigApplicationContext context;
	@Before
	public void init(){
		context =new AnnotationConfigApplicationContext();
		context.scan("com.project.*");
		context.refresh();
		productDAO=(ProductDAO)context.getBean("productDAO");
		product=(Product)context.getBean("product");
	}
		
	@Test
	public void productAddTestCase(){
		
		product.setId("CAT_03");
		product.setName("MOBILES");
		product.setDescription("MOBILE PHONES AND TABLETS");
		product.setPrice("9000");
		assertEquals("AddTestCase", productDAO.save(product),true);
	}
	@Test
	public void productUpdateTestCase(){
		product.setId("CAT_04");
		product.setName("SECURITY");
		product.setDescription("SECURITY SOLUTIONS EX,CCTV ");
		assertEquals("UpdateTestCase", productDAO.save(product),true);
	}
	@Test
	public void categoryDeleteTestCase()
	{                              
		product.setId("CAT_04");
		boolean flag = productDAO.delete(product);
		assertEquals("DeleteTestCase " , flag,true);
	    productDAO.delete(product);
	}

		}
	
	
	

