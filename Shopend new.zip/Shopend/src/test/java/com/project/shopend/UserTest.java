package com.project.shopend;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.project.shopping.DAO.UserDAO;
import com.project.shopping.Model.User;



public class UserTest {
	public static void main(String[] args){
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.project.*");
		context.refresh();
		UserDAO userDAO=(UserDAO) context.getBean("userDAO");
		User user=(User) context.getBean("user");
		user.setId("ud_001");
		user.setFirstname("lakshmi");
		user.setLastname("preethi");
		user.setMail("tk@yahoo.com");
		user.setPassword("lakshuu95");
		user.setPhonenumber("9940090967");
		
		if(userDAO.save(user) == true) 
		{
			System.out.println("user created successfully");
		}
		else
		{
			System.out.println("not able to create the user");
		}
}
}

