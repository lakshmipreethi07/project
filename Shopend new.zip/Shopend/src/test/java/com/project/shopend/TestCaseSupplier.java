package com.project.shopend;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.project.shopping.DAO.SupplierDAO;
import com.project.shopping.Model.Supplier;



public class TestCaseSupplier {

	@Autowired
	SupplierDAO supplierDAO;
	@Autowired
	Supplier supplier;
	AnnotationConfigApplicationContext context;
	@Before
	public void init(){
		context =new AnnotationConfigApplicationContext();
		context.scan("com.project.*");
		context.refresh();
		supplierDAO=(SupplierDAO)context.getBean("supplierDAO");
		supplier=(Supplier)context.getBean("supplier");
	}
		
	@Test
	public void supplierAddTestCase(){
		
		supplier.setId("SUP_01");
		supplier.setName("Lakshmi preethi.P");
		supplier.setDescription("MOBILE PHONES AND TABLETS");
		supplier.setSupplier_address("no12 Nandanam");
		supplier.setSupplier_product_name("MOBILE PHONES");
		assertEquals("AddTestCase", supplierDAO.save(supplier),true);
	}
			}
	
	
	

