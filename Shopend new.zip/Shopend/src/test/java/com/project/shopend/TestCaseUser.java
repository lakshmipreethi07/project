package com.project.shopend;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.project.shopping.DAO.UserDAO;
import com.project.shopping.Model.User;


public class TestCaseUser {

	@Autowired
	UserDAO userDAO;
	@Autowired
	User user;
	AnnotationConfigApplicationContext context;
	@Before
	public void init(){
		context =new AnnotationConfigApplicationContext();
		context.scan("com.project.*");
		context.refresh();
		userDAO=(UserDAO)context.getBean("userDAO");
		user=(User)context.getBean("user");
	}
		
	@Test
	public void userAddTestCase(){
		
		user.setId("CAT_03");
		user.setFirstname("pushpa");
		user.setLastname("priya");
		user.setMail("pushii@yahoo.com");
		user.setPassword("priya");
		user.setPhonenumber("9894309005");
		assertEquals("AddTestCase", userDAO.save(user),true);
	}
	@Test
	public void UserUpdateTestCase(){
		user.setId("us_003");
		user.setFirstname("prem");
		user.setLastname("kumar");
		user.setMail("premkumar@yahoo.com");
		user.setPassword("premkumar");
		user.setPhonenumber("9977563232");
		
		assertEquals("UpdateTestCase", userDAO.save(user),true);
	}
	@Test
	public void categoryDeleteTestCase()
	{                              
		user.setId("us_003");
		boolean flag = userDAO.delete(user);
		assertEquals("DeleteTestCase " , flag,true);
	    userDAO.delete(user);
	}

		}
	
	
	

