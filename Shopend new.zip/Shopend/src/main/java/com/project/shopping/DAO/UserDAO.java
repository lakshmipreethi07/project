package com.project.shopping.DAO;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.project.shopping.Model.User;




@Repository
public interface UserDAO {
	
	public boolean save(User user);
	
	public boolean update(User user);
	
	 public boolean delete(User user);
	 
	 public User get(String id);
	 
	 public List <User> list();
	 
}
