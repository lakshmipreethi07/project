package com.niit.shoppingcart;


import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.shopping.DAO.CategoryDAO;
import com.project.shopping.DAO.SupplierDAO;
import com.project.shopping.DAO.UserDAO;
import com.project.shopping.Model.Category;
import com.project.shopping.Model.Supplier;
import com.project.shopping.Model.User;

@Controller
public class UserController {
	
	@Autowired
	User user;
	
	@Autowired
	UserDAO userDAO;
	
	@Autowired
	Supplier supplier;
	
	@Autowired
	SupplierDAO supplierDAO;
	
	@Autowired
	Category category;
	
	@Autowired
	CategoryDAO categoryDAO;
	
	
	@RequestMapping("/login")
	public ModelAndView login(@RequestParam(value="name")String userID,
			@RequestParam(value="password") String password,HttpSession session)
	{
	ModelAndView mv=new ModelAndView("home");
	boolean isValidUser=userDAO.isValidUser(userID,password);
	if(isValidUser==true){
		user=userDAO.get(userid);
		session.setAttribute("loggedInUser",user.getFirstname());
		session.setAttribute("loggedInUserID",user.getId());
		session.setAttribute("user",user);
		
	}
	else{
		if(user.getRole().equals("ROLE_ADMIN"))
		{
			mv.addObject("isAdmin","true");
			session.setAttribute("supplier",supplier);
			session.setAttribute("supplierList",supplierDAO.list());
			session.setAttribute("category",category);
			session.setAttribute("categoryList",categoryDAO.list());
			
		}
	}

	
