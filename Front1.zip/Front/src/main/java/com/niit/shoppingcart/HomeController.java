package com.niit.shoppingcart;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.project.shopping.DAO.CategoryDAO;
import com.project.shopping.DAO.UserDAO;
import com.project.shopping.Model.Category;
import com.project.shopping.Model.User;


@Controller
public class HomeController{
	@Autowired
	private Category category;
	
	@Autowired
	private CategoryDAO categoryDAO;
	
	
	@Autowired
	private UserDAO userDAO;
	
	
	@Autowired
	private User user;
	
	
	@RequestMapping("/")
	public ModelAndView  onLoad(HttpSession session)
	{
		ModelAndView mv =new ModelAndView("/home");
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
		System.out.println("size:"+categoryDAO.list());
		return mv;
	}
	@RequestMapping(value="user/register",method=RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute User user)
	{
		ModelAndView mv=new ModelAndView("/home");
		if(userDAO.get(user.getId())==null)
		{
			userDAO.update(user);
			mv.addObject("successs message","you are successfully register");
		}
		else
		{
			mv.addObject("msg","user exits with this id");
		}
		return mv;
		
	}
	@RequestMapping("/registerhere")
	public ModelAndView registerhere()
	{
		ModelAndView mv=new ModelAndView("/home");
		mv.addObject("user","user");
		mv.addObject("isUserclickedregister","true");
		return mv;
		
	}
	
	@RequestMapping("/loginhere")
public ModelAndView loginhere()
{
		ModelAndView mv=new ModelAndView("/home");
		mv.addObject("user", user);
		mv.addObject("isuserclickedloginhere","true");
		return mv;	
	
}
}
