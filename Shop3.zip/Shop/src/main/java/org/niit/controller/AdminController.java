package org.niit.controller;
import org.niit.dao.CategoryDAO;
import org.niit.dao.SupplierDAO;
import org.niit.model.Category;
import org.niit.model.Supplier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class AdminController {


@Autowired
private Category category;


@Autowired
private CategoryDAO categoryDAO;

@Autowired
private SupplierDAO supplierDAO;

@Autowired
private Supplier supplier;

@RequestMapping("/manageCategories")
public ModelAndView manageCategories(){
	ModelAndView mv= new ModelAndView("Category");
	mv.addObject("category",category);
	return mv;
	
	
}
@RequestMapping("/manageSuppliers")
public ModelAndView manageSuppliers(){
	ModelAndView mv= new ModelAndView("Supplier");
	mv.addObject("Supplier",supplier);
	return mv;
	
}
}

