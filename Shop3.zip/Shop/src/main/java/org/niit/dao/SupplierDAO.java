package org.niit.dao;
import java.util.List;

import org.springframework.stereotype.Repository;



import org.niit.model.Category;
import org.niit.model.Supplier;


@Repository
public interface SupplierDAO {
	
	public boolean saveOrUpdate(Supplier supplier);
		
		public void delete(String id);
		
		
		public List<Supplier> list();
				

		 public Supplier get(String id);	

}




