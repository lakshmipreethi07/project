package org.niit.controller;
import org.niit.dao.CategoryDAO;
import org.niit.model.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class AdminController {


@Autowired
private Category category;


@Autowired
private CategoryDAO categoryDAO;




@RequestMapping("/manageCategories")
public ModelAndView manageCategories(){
	ModelAndView mv= new ModelAndView("Category");
	mv.addObject("category",category);
	return mv;
	
	
}
}


